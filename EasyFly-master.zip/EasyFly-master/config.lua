application =
{

	content =
	{
		
		width = 320,
		height = 480, 
		scale = "adaptative" --,zoomEven, letterbox, adaptative, zoomStretch
		
		
		--[[
		imageSuffix =
		{
			    ["@2x"] = 2,
		},
		--]]
	},

	--[[
	-- Push notifications
	notification =
	{
		iphone =
		{
			types =
			{
				"badge", "sound", "alert", "newsstand"
			}
		}
	},
	--]]    
}
